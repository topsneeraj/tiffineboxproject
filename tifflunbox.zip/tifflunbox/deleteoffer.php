<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    ;
    
    $offer_id=$_POST['offer_id'];
    $sp_id=$_POST['sp_id'];
   
    
    
    echo $qu="DELETE FROM `offer` WHERE  offer_id='$offer_id' and sp_id='$sp_id'";
    
    
    $con->query($qu);
    echo "success";
    
    
    ?>
