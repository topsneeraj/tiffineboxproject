<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    
    $del_email = $_POST['del_email'];
    $del_password = $_POST['del_password'];
    
    
    $qu="SELECT * FROM D_registraion WHERE del_email='$del_email' and del_password='$del_password'";
    
    $pp=$con->query($qu);
    
    while($ff=$pp->fetch_object())
    {
        $qq[]=$ff;
    }
    echo json_encode($qq);
    
    
    ?>
