<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    
    $sp_id = $_POST['sp_id'];
    $tc_type = $_POST['tc_type'];
    
    
    $qu="SELECT * FROM tiffin_items WHERE sp_id='$sp_id' and tc_type='$tc_type'";
    
    $pp=$con->query($qu);
    
    while($ff=$pp->fetch_object())
    {
        $qq[]=$ff;
    }
    echo json_encode($qq);
    
    
    ?>
