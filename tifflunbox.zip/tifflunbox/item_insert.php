<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    define('UPLOAD_DIR', 'item_images/');
    
    
    $sp_id=$_POST['sp_id'];
    $tc_type=$_POST['tc_type'];
    $img=$_POST['item_img'];
    $item_name=$_POST['item_name'];
    $item_detail=$_POST['item_detail'];
    $item_price=$_POST['item_price'];
    
    
    $img = str_replace('data:image/png;base64,', '', $img);
    $img = str_replace(' ', '+', $img);
    $data = base64_decode($img);
    $file = UPLOAD_DIR . uniqid() . '.png';
    $success = file_put_contents($file, $data);
    print $success ? $file : 'Unable to save the file.';
    
    $sel="select * from tiffin_items where sp_id='$sp_id' and item_name='$item_name'";
    $qe=$con->query($sel);
    $nm=$qe->num_rows;
    if($nm>0)
    {
        $dd=array("error"=>"alrady exist..");
        echo json_encode($dd);
        
    }
    else
    {
        echo    $qu="insert into tiffin_items(sp_id,tc_type,item_img,item_name,item_detail,item_price)values('$sp_id','$tc_type','$file','$item_name','$item_detail','$item_price')";
        
        
        $con->query($qu);
        echo "success";
    }

    
?>
