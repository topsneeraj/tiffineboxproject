<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    
    $sp_id=$_POST['sp_id'];
    $offer_id=$_POST['offer_id'];
    
    
    
    $qu="SELECT * FROM offer WHERE sp_id='$sp_id' and offer_id='$offer_id'";
    
    $pp=$con->query($qu);
    
    while($ff=$pp->fetch_object())
    {
        $qq[]=$ff;
    }
    echo json_encode($qq);
    
    
    ?>
