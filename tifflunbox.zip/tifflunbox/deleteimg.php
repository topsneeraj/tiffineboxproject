<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    ;
    
    $img_id=$_POST['img_id'];
    $sp_id=$_POST['sp_id'];
   
    
    
    echo $qu="DELETE FROM `images` WHERE  img_id='$img_id' and sp_id='$sp_id'";
    
    
    $con->query($qu);
    echo "success";
    
    
    ?>
