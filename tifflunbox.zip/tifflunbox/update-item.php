<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    define('UPLOAD_DIR', 'item_images/');
    
    $item_id=$_POST['item_id'];
    $sp_id=$_POST['sp_id'];
    $tc_type=$_POST['tc_type'];
    $img=$_POST['item_img'];
    $item_name=$_POST['item_name'];
    $item_price=$_POST['item_price'];
    $item_detail=$_POST['item_detail'];
    
    $img = str_replace('data:image/png;base64,', '', $img);
    $img = str_replace(' ', '+', $img);
    $data = base64_decode($img);
    $file = UPLOAD_DIR . uniqid() . '.png';
    $success = file_put_contents($file, $data);
    print $success ? $file : 'Unable to save the file.';
    
    echo $qu="UPDATE tiffin_items SET item_img='$file',item_name='$item_name',item_price='$item_price',item_detail='$item_detail' WHERE item_id='$item_id' and tc_type='$tc_type' and sp_id='$sp_id'";
    
    
    $con->query($qu);
    echo "success";
    
    
    ?>
