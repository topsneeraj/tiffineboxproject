<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    define('UPLOAD_DIR', 'rguser_img/');
    


    $emil=$_POST['user_email'];
    $password=$_POST['user_password'];
    
    
    $sel="select * from Ragistration where user_email='$email'";
    $qe=$con->query($sel);
    $nm=$qe->num_rows;
    if($nm>0)
    {
        $dd=array("error"=>"alrady exist..");
        echo json_encode($dd);
        
    }
    else
    
    {
    echo $qu="insert into Ragistration(user_email,user_password) 	values('$emil','$password')";
    
    
    $con->query($qu);
    echo "success";
    }
    
    ?>





