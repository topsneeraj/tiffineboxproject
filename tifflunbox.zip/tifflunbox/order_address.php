<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    
    
    
    $user_email=$_POST['user_email'];
    $sp_id=$_POST['sp_id'];
    $order_id=$_POST['order_id'];
    $address2=$_POST['address2'];
    
    $sel="select * from user_order_address where order_id='$order_id'";
    $qe=$con->query($sel);
    $nm=$qe->num_rows;
    if($nm>0)
    {
        $dd=array("error"=>"alrady exist..");
        echo json_encode($dd);
        
    }
    else
    {
        echo $qu="insert into user_order_address(user_email,sp_id,order_id,address2) 	values('$user_email','$sp_id','$order_id',address2)";
        
        
        $con->query($qu);
        echo "success";
    }
    
    ?>



