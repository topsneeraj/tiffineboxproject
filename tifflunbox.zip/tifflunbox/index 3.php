<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
 

    $email_id=$_POST['email_id'];
    $otp=$_POST['otp'];
    

    echo $qu="insert into otp(email_id,otp_no) 	values('$email_id','$otp_no')";

    $con->query($qu);
    echo "success";
    
    
    ?>

