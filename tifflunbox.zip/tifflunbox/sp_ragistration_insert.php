<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    
    
        $name=$_POST['sp_username'];
        $email=$_POST['sp_email'];
        $password=$_POST['sp_password'];
    
    $sel="select * from sp_ragistration where sp_email='$email'";
    $qe=$con->query($sel);
    $nm=$qe->num_rows;
    if($nm>0)
    {
        $dd=array("error"=>"alrady exist..");
        echo json_encode($dd);
        
    }
    else
    {
        echo $qu="insert into sp_ragistration(sp_username,sp_email,sp_password) 	values('$name','$email','$password')";
    
    
        $con->query($qu);
        echo "success";
    }

?>





