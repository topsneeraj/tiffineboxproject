<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    
    
    
    $sp_id=$_POST['sp_id'];
    $name=$_POST['user_name'];
    $img = $_POST['user_img'];
    $msg=$_POST['msg'];
 
    
    
  echo $qu="insert into user_msg(sp_id,msg,user_name,user_img) 	values('$sp_id','$msg','$name','$img')";
    
    
    $con->query($qu);
    echo "success";
?>
