<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    define('UPLOAD_DIR', 'licenseimg/');
    
    
    
    $sp_id=$_POST['sp_id'];
    $img=$_POST['license'];
    
    
    
    $img = str_replace('data:image/png;base64,', '', $img);
    $img = str_replace(' ', '+', $img);
    $data = base64_decode($img);
    $file = UPLOAD_DIR. uniqid() . '.png';
    $success = file_put_contents($file, $data);
    print $success ? $file : 'Unable to save the file.';
    
    
    echo $qu="UPDATE sp_ragistration SET license='$file' WHERE sp_id='$sp_id'";
    
    $con->query($qu);
    echo "success";
    
    
    ?>
