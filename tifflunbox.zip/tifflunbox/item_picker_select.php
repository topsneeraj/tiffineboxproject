<?php
    
    $con=new mysqli("localhost","root","","tifflunbox");
    
    $sp_id = $_POST['sp_id'];
    
    
    
    $qu="SELECT tc_type FROM tiffin_categaries WHERE sp_id='$sp_id'";
    
    $pp=$con->query($qu);
    
    while($ff=$pp->fetch_object())
    {
        $qq[]=$ff;
    }
    echo json_encode($qq);
    
    
    ?>
