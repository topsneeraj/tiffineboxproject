//
//  itemtype_cell.h
//  servicesprovaider
//
//  Created by Admin on 19/03/17.
//  Copyright © 2017 mine. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface itemtype_cell : UITableViewCell


    @property (weak, nonatomic) IBOutlet UILabel *item_type;


@end
