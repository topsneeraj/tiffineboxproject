//
//  order-cell.h
//  servicesprovaider
//
//  Created by Admin on 18/03/17.
//  Copyright © 2017 mine. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface order_cell : UITableViewCell

@end
