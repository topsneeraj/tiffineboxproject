
//
//  menu-cell.m
//  servicesprovaider
//
//  Created by Admin on 18/03/17.
//  Copyright © 2017 mine. All rights reserved.
//

#import "menu-cell.h"

@implementation menu_cell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    

    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)delet:(id)sender {
}
@end
