//
//  login.m
//  tifflunbox(delivry moduel)
//
//  Created by Admin on 20/04/17.
//  Copyright © 2017 Admin. All rights reserved.
//

#import "login.h"
#import "registration.h"
#import "home_page.h"

@interface login ()
#define REGEX_EMAIL @"[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9]{3,}+\\.[A-Za-z]{2,4}"
#define REGEX_PASSWORD_LIMIT @"^.{6,20}$"
#define REGEX_PASSWORD @"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$"

//(?=.*?[#?!@$%^&*-])

{
    NSMutableArray *final1;
    
}

@end

@implementation login

- (void)viewDidLoad {
    [super viewDidLoad];

    
    
    
    self.login.clipsToBounds = YES;
    _password.secureTextEntry=YES;
    [self validate];
    
    
}
-(void)validate
{
    
    [_login  addRegx:REGEX_EMAIL withMsg:@"enter valid username"];
    
    _login.presentInView=self.view;
    [_password addRegx:REGEX_PASSWORD withMsg:@"Minimum one uppercase later and one lower case later and one numeric value To valid"];
    _password.presentInView=self.view;
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    
}



- (IBAction)loginbtn:(id)sender {
    if(_login.validate && _password.validate)
    {
        
        
        // NSLog(@"all data is write");
        
        
        
        NSURL *url=[NSURL URLWithString:@"http://localhost/tifflunbox/d_login.php"];
        
        NSString *strbody=[NSString stringWithFormat:@"user_email=%@&user_password=%@",_login.text,_password.text];
        
        
        NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:url];
        
        NSString *strlen=[NSString stringWithFormat:@"%ld",strbody.length];
        
        [request addValue:strlen forHTTPHeaderField:@"Content-Legnth"];
        
        [request setHTTPMethod:@"POST"];
        
        [request setHTTPBody:[strbody dataUsingEncoding:NSUTF8StringEncoding]];
        
        NSURLSession *session=[NSURLSession sharedSession];
        
        NSURLSessionDataTask *task=[session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error)
                                    {
                                        
                                        
                                        NSArray *arr=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
                                        
                                        NSLog(@"%@",[arr description]);
                                        
                                        
                                        dispatch_async(dispatch_get_main_queue(), ^
                                                       {
                                                         
                                                           
                                                           
                                                           if([arr count]==1)
                                                           {
                                                               
                                                               
                                                               for (NSDictionary *dic3 in arr) {
                                                                   NSMutableArray *temp=[[NSMutableArray alloc]init];
                                                                   
                                                                   [temp addObject:[dic3 valueForKey:@"user_email"]];
                                                                   
                                                                   [temp addObject:[dic3 valueForKey:@"user_img"]];
                                                                   
                                                                   [temp addObject:[dic3 valueForKey:@"user_name"]];
                                                                   
                                                                   [temp addObject:[dic3 valueForKey:@"user_id"]];
                                                                   
                                                                   NSUserDefaults *dif = [NSUserDefaults standardUserDefaults];
                                                                   NSString *str=[temp objectAtIndex:0];
                                                                   NSString *str1=[temp objectAtIndex:1];
                                                                   NSString *str2=[temp objectAtIndex:2];
                                                                   NSString *userid=[temp objectAtIndex:3];
                                                                   
                                                                   [dif setObject:str forKey:@"useremail"];
                                                                   
                                                                   [dif setObject:str1 forKey:@"userimg"];
                                                                   
                                                                   [dif setObject:str2 forKey:@"username"];
                                                                   
                                                                   [dif setObject:userid forKey:@"userid"];
                                                                   
                                                                   
                                                                   [dif setObject:@"1" forKey:@"login_status"];
                                                                   
                                                               }
                                                               
                                                               
                                                               
                                                               
                                                               
                                                           }
                                                           else
                                                           {
                                                               
                                                               
                                                               
                                                               UIAlertController *alt=[UIAlertController alertControllerWithTitle:@"Login error" message:@"Your Login detail is not match" preferredStyle:UIAlertControllerStyleAlert];
                                                               
                                                               UIAlertAction *okAction = [UIAlertAction
                                                                                          actionWithTitle:NSLocalizedString(@"OK", @"OK action")
                                                                                          style:UIAlertActionStyleDefault
                                                                                          handler:^(UIAlertAction *action)
                                                                                          {
                                                                                              NSLog(@"OK action");
                                                                                          }];
                                                               [alt addAction:okAction];
                                                               
                                                               [self presentViewController:alt animated:YES completion:nil];

                                                               
                                                           }
                                                           
                                                       });
                                        
                                        
                                    }];
        
        
        [task resume];
        
    }
}

- (IBAction)signupbtn:(id)sender {

    
    registration*s1=[self.storyboard instantiateViewControllerWithIdentifier:@"registration"];
    
    [self.navigationController pushViewController:s1 animated:YES];
    
}


@end
