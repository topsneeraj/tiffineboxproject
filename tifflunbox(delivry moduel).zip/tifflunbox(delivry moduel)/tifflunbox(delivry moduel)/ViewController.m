//
//  ViewController.m
//  tifflunbox(delivry moduel)
//
//  Created by Admin on 20/04/17.
//  Copyright © 2017 Admin. All rights reserved.
//

#import "ViewController.h"
#import "home_page.h"
#import "login.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSUserDefaults *dif=[NSUserDefaults standardUserDefaults];
    NSString *str=[dif valueForKey:@"login_status"];
    if([str isEqualToString:@"1"]){
        
        home_page*s1=[self.storyboard instantiateViewControllerWithIdentifier:@"m3"];
        
        
        [self.navigationController pushViewController:s1 animated:YES];
    
}

    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(myfun)];
    _v1.userInteractionEnabled=YES;
    
    tap.numberOfTapsRequired=1;
    [_v1 addGestureRecognizer:tap];
}
    
-(void)myfun
{
    login *l1=[self.storyboard instantiateViewControllerWithIdentifier:@"login"];
    
    [self.navigationController pushViewController:l1 animated:YES];
}

    

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


@end
