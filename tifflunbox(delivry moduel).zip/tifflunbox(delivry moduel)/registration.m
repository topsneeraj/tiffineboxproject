//
//  registration.m
//  tifflunbox(delivry moduel)
//
//  Created by Admin on 20/04/17.
//  Copyright © 2017 Admin. All rights reserved.
//

#import "registration.h"
#import "insert_profile.h"

@interface registration ()

@end

@implementation registration
#define REGEX_USER_NAME_LIMIT @"^.{3,10}$"
#define REGEX_USER_NAME @"[A-Za-z0-9]{3,10}"
#define REGEX_EMAIL @"[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9]{3,}+\\.[A-Za-z]{2,4}"
#define REGEX_PASSWORD_LIMIT @"^.{6,20}$"
#define REGEX_PASSWORD @"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$"

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
     [self validate];
}

-(void)validate
{
    
    
    
    
    [_email addRegx:REGEX_EMAIL withMsg:@"password not valid"];
    _email.presentInView=self.view;
    
    [_password addRegx:REGEX_PASSWORD withMsg:@"Minimum one uppercase later and one lower case later and one numeric value To valid"];
    _password.presentInView=self.view;
    
    [_ver_password addRegx:REGEX_PASSWORD withMsg:@"Minimum one uppercase later and one lower case later and one numeric value To valid"];
    _ver_password.presentInView=self.view;
    
    
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)singup:(id)sender {
    if(_email.validate && _password.validate && _ver_password.validate )
    {
        if (_password.text == _ver_password.text) {
            
            
            
            NSURL *url=[NSURL URLWithString:@"http://localhost/tifflunbox/d_registration.php"];
            
            NSString *strbody=[NSString stringWithFormat:@"del_email=%@&del_password=%@",_email.text,_password.text];
            
            NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:url];
            
            NSString *strlen=[NSString stringWithFormat:@"%ld",strbody.length];
            
            [request addValue:strlen forHTTPHeaderField:@"Content-Legnth"];
            
            [request setHTTPMethod:@"POST"];
            
            [request setHTTPBody:[strbody dataUsingEncoding:NSUTF8StringEncoding]];
            
            NSURLSession *session=[NSURLSession sharedSession];
            
            NSURLSessionDataTask *task=[session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                
                
                NSString *str=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
                
                NSLog(@"%@",str);
                
                
            }];
            
            
            [task resume];
            
            
            NSUserDefaults *dif = [NSUserDefaults standardUserDefaults];
            NSString *str =_email.text;
            [dif setObject:str forKey:@"useremail"];
            
            insert_profile*p1=[self.storyboard instantiateViewControllerWithIdentifier:@"i_pro"];
            [self.navigationController pushViewController:p1 animated:YES];
            
            
        }
        else {
            
            UIAlertController *alt=[UIAlertController alertControllerWithTitle:@"Password error" message:@"Your Password is not match" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *okAction = [UIAlertAction
                                       actionWithTitle:NSLocalizedString(@"OK", @"OK action")
                                       style:UIAlertActionStyleDefault
                                       handler:^(UIAlertAction *action)
                                       {
                                           NSLog(@"OK action");
                                       }];
            [alt addAction:okAction];
            
            [self presentViewController:alt animated:YES completion:nil];
            
        }
        
        
    }
    

    
}
@end
