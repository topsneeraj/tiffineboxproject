//
//  registration.h
//  tifflunbox(delivry moduel)
//
//  Created by Admin on 20/04/17.
//  Copyright © 2017 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TextFieldValidator.h"


@interface registration : UIViewController
@property (weak, nonatomic) IBOutlet TextFieldValidator *email;
@property (weak, nonatomic) IBOutlet TextFieldValidator *password;
@property (weak, nonatomic) IBOutlet TextFieldValidator *ver_password;
- (IBAction)singup:(id)sender;


@end
