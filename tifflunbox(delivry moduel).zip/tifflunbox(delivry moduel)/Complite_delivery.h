//
//  Complite_delivery.h
//  tifflunbox(delivry moduel)
//
//  Created by Admin on 21/04/17.
//  Copyright © 2017 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Complite_delivery : UIViewController

@end
